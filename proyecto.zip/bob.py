from cqc.pythonLib import CQCConnection

def run_bob():
    with CQCConnection("Bob") as bob:
        q = bob.recvEPR()
        print("[BOB] Qubit EPR recibido.")
        m = q.measure()
        print(f"[BOB] Resultado de medición: {m}")
        with open("bob_resultado.txt", "w") as f:
            f.write(str(m))

if __name__ == "__main__":
    run_bob()
