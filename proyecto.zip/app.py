import os
import subprocess
import time
from flask import Flask, render_template, redirect, url_for

app = Flask(__name__)

@app.route("/")
def index():
    try:
        with open("bob_resultado.txt", "r") as f:
            resultado = f.read()
    except FileNotFoundError:
        resultado = "Aún no se ha realizado la simulación."
    return render_template("index.html", resultado=resultado)

@app.route("/simular")
def simular():
    print("[WEB] Iniciando simulación...")
    subprocess.Popen(["python3", "bob.py"])
    time.sleep(1)
    subprocess.Popen(["python3", "alice.py"])
    time.sleep(3)
    return redirect(url_for("index"))

if __name__ == "__main__":
    app.run(debug=True)
