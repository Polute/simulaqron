from cqc.pythonLib import CQCConnection

def run_alice():
    with CQCConnection("Alice") as alice:
        q = alice.createEPR("Bob")
        print("[ALICE] Par EPR creado y enviado a Bob.")
        m = q.measure()
        print(f"[ALICE] Resultado de medición: {m}")

if __name__ == "__main__":
    run_alice()
